import React, { Component } from 'react';
import '../styles/App.css';

import Main from './Main';
import {Route, NavLink, BrowserRouter as Router, Switch} from 'react-router-dom'
import Products from './Product/Products';
import Product from './Product/Product';
import Applications from './Applications/Applications';
import Notfound from './Notfound';
import LangContext from './LangContext';



class App extends Component {
    constructor(){
        super();
          this.state={
                results: {},
                language: "sv-se",
                setLanguage: ({ value }) => {
                    this.setState({ language: value });
                    console.log(this.state.language);
                }
          }
      }

      render() {
        return (
            <div className="App">
                <div className="main-container">
                    <LangContext.Provider value={this.state}>
                        <Router>
                            <div className="main-router">
                                <Switch>
                                    <Route exact path="/" component={Main} />
                                    <Route exact path="/Products" component={Products} />
                                    <Route path="/Products/:id" component={Product} />
                                    <Route path="/Product/Description/:id" component={Product} />
                                    <Route path="/Product/Documents/:id" component={Product} />
                                    <Route path="/Product/Images/:id" component={Product} />
                                    <Route path="/Product/Videos/:id" component={Product} />
                                    <Route path="/Contact" component={Product} />
                                    <Route path="/Applications/:id" component={Applications} /> 
                                    <Route path="/Application/Description/:id" component={Applications} />
                                    <Route path="/Application/Documents/:id" component={Applications} />
                                    <Route path="/Application/Images/:id" component={Applications} />
                                    <Route path="/Application/Videos/:id" component={Applications} />
                                    <Route path="/Contact" component={Applications} />
                                    <Route component={Notfound} />
                                </Switch>
                            </div>
                        </Router>
                    </LangContext.Provider>
                </div>
            </div>
        );
    }
}

export default App;

