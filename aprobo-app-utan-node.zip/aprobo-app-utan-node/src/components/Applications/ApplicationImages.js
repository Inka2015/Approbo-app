import React, { Component } from 'react';

class ApplicationImages extends React.Component{
    constructor(props){
        super(props)
    }
   
      render() {
        const items = this.props.images.map((a) =>
            <li key={a.id}>
                <img src={a.URL} />
            </li>
        );
        
        return(
            <div className="Application-image-container">
                <div className="subpage-container">
                    <div className="container">
                        <div className="row">
                            <div className="col-md-12">
                                <ul className="image-list">
                                    {items}
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        )
    }
}

export default ApplicationImages;