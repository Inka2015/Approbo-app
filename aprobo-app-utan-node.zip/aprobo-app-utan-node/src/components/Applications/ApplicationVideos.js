import React, { Component } from 'react';

class ApplicationVideos extends React.Component{
    constructor(props){
        super(props)
    }
   
    rawMarkup(){
        var rawMarkup = this.props.videoHtml
        return { __html: rawMarkup };
    }

    render() {

        
        return(
            <div className="Application-video-container">
                <div className="subpage-container">
                    <div className="container">
                        <div className="row">
                            <div className="col-md-12">
                                <div className="video" dangerouslySetInnerHTML={this.rawMarkup()} />
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        )
    }
}

export default ApplicationVideos;