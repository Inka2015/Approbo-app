import React, { Component } from 'react';
import '../../styles/App.css';
import Header from "../Header/Header"
import axios from "axios";
import ApplicationDescription from './ApplicationDescription';
import ApplicationDocuments from './ApplicationDocuments';
import ApplicationImages from './ApplicationImages';
import ApplicationVideos from './ApplicationVideos';
import Contact from '../Conatct/Contact';
import Goback from '../Header/Goback';
import ApplicationRedirect from './ApplicationRedirect';
import {
    Route,
    NavLink,
    BrowserRouter as Router,
    Switch,
  } from 'react-router-dom'

class Application extends React.Component{
    state={
        application: {}, 
        images: [],
        documents: [],
        videoHtml: []
    };

    componentDidMount(){
        let pr = "https://aprobo.inkadev.nu/umbraco/api/Products/GetproductApplication/" + this.props.match.params.id;
        
        let axiosConfig = {
            headers: {
                'Content-Language': 'en-Us'
            }
        };
        axios
        .get(pr, axiosConfig)
        .then(response => {
            const newApplication = response.data;

            const newState = Object.assign({}, this.state, {
                application: newApplication,
                images: newApplication.images,
                documents: newApplication.documents,
                videoHtml: newApplication.videoHtml,
            });

            this.setState(newState);
        })

        .catch(error => console.log(error));
    }

    render() {
        return(
            <div className="applications-page">
                <Header />
                <div className="header-banner">
                    <Goback />
                    <h2 className="header-title"><a href="/products">{this.state.application.name}</a></h2>
                </div>
                <Router> 
                    <Switch>
                        <Route path="/Applications/:id" render={(props) => <ApplicationRedirect {...props} applications={this.state.applications}/>} />
                        <Route path="/Application/Description/:id" render={(props) => <ApplicationDescription {...props} applications={this.state.applications} product={this.state.product} />} />
                        <Route path="/Application/Videos/:id" render={(props) => <ApplicationVideos {...props} videoHtml={this.state.videoHtml}/>} />
                        <Route path="/Application/Documents/:id" render={(props) => <ApplicationDocuments {...props} documents={this.state.documents}/>} />
                        <Route path="/Application/Images/:id" render={(props) => <ApplicationImages {...props} images={this.state.images}/>} />
                        <Route path="/Contact" component={Contact} />
                    </Switch>
                    <div className="product-menu-container">
                        <ul className="product-menu">
                            <li>
                                <NavLink activeClassName="active" to={`/application/Videos/${this.props.match.params.id}`}>
                                    <i className="fa fa-film"></i>
                                    Videos
                                </NavLink>
                            </li>
                            <li>
                                <NavLink activeClassName="active" to={`/application/Documents/${this.props.match.params.id}`}>
                                    <i className="fa fa-file"></i>
                                    Documents
                                </NavLink>
                            </li>
                            <li>
                                <NavLink activeClassName="active" to={`/application/Images/${this.props.match.params.id}`}>
                                    <i className="fa fa-image"></i>
                                    Images
                                </NavLink>
                            </li>
                            <li>
                                <NavLink activeClassName="active" to="/Contact">
                                    <i className="fa fa-info-circle"></i>
                                    Contact
                                </NavLink>
                            </li>
                        </ul>
                    </div>
                </Router>
            </div>
        )
    }
}

export default Application;