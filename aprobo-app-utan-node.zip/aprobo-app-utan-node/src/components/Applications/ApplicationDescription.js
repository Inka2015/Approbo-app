import React, { Component } from 'react';

class ApplicationDescription extends React.Component{
    constructor(props){
        super(props)
    }

    rawMarkup(){
        var rawMarkup = this.props.application.shortDescription
        return { __html: rawMarkup };
    }

    rawMarkupHtml(){
        var rawMarkup = this.props.application.htmlDescription
        return { __html: rawMarkup };
    }

    render() {
        return(
            <div className="subpage-container">
                <div className="container">
                    <div className="row">
                        <div className="col-md-12">
                            <div className="ingress" dangerouslySetInnerHTML={this.rawMarkup()} />
                            <div className="html-description" dangerouslySetInnerHTML={this.rawMarkupHtml()} />
                        </div>
                    </div>
                </div>
            </div>
        )
    }
}

export default ApplicationDescription;