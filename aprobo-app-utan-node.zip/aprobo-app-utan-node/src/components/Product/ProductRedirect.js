import React, { Component } from 'react';
import {
    Route,
    BrowserRouter as Router,
    Redirect
  } from 'react-router-dom'


  class ProductRedirect extends React.Component{
    constructor(props){
        super(props)
    }

    render(){
        let Id = this.props.match.params.id;
        return(
            <Redirect to={`/Product/Description/${Id}`} />
        )
    }

}

export default ProductRedirect;