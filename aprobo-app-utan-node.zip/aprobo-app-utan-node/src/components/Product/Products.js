import React from 'react';
import '../../styles/App.css';
import axios from "axios";
import Header from '../Header/Header';
import Goback from '../Header/Goback';
import LangContext from '../LangContext';

class Products extends React.Component{
    static contextType = LangContext;

    constructor(){
        super();
            this.state={
                products: [],
                productImage: {},
                translations: [],
                language: "",
                setLang: ({ value }) => this.setState({ language: value })
            };
      }

     componentDidUpdate(prevProps, prevState){
        if(prevState.language !== this.context.language){ 
        this.state.language = this.context.language;

        let pr = "https://aprobo.inkadev.nu/umbraco/api/Products/GetAllProducts";

        let value = this.context;

        let axiosConfig = {
            headers: {
                'Content-Language': value.language
            }
        };
        
        axios
        .get(pr, axiosConfig)
        .then(response => {
            const newProducts = response.data;

            const newState = Object.assign({}, this.state, {
                products: newProducts,
                productImage: newProducts.productImage

            });

            this.setState(newState);
        })

        .catch(error => console.log(error));

        let translations ="https://aprobo.inkadev.nu/umbraco/api/Products/GetDictionaryItems";

        axios
        .get(translations, axiosConfig)
        .then(response => {
            const newTranslations = response.data;

            const newState = Object.assign({}, this.state, {
                translations: newTranslations
            });

            this.setState(newState);
        })

        .catch(error => console.log(error));
        }
    }

    componentDidMount(){
        let pr = "https://aprobo.inkadev.nu/umbraco/api/Products/GetAllProducts";
 
        axios
        .get(pr)
        .then(response => {
            const newProducts = response.data;

            const newState = Object.assign({}, this.state, {
                products: newProducts,
                productImage: newProducts.productImage

            });

            this.setState(newState);
        })

        .catch(error => console.log(error));
    }

    render(){
        const items = this.state.products.map((p) =>
            <li key={p.id}>
                <a href={`/products/${p.id}`}>
                    <img src={p.productImageUrl}/>
                </a>
            </li>
        );
        
        return(
            <div className="product-container">
                <Header />
                <div className="header-banner">
                  <Goback />
                  <h2 className="header-title">{this.state.translations.products_title}</h2>
               </div>
                <div className="subpage-container">
                    <div className="container">
                        <div className="row">
                            <div className="col-md-12">
                                <ul className="products">
                                    {items}
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        )
    }
}

export default Products;
