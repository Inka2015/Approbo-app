import React from 'react';

const LangContext = React.createContext();
 
export default LangContext;

